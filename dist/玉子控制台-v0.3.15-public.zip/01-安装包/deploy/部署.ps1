# 玉子控制台 · 一键部署（全新电脑用）
# 用法（管理员 PowerShell）：
#   powershell -ExecutionPolicy Bypass -File 部署.ps1
# 可选参数：
#   -Root "D:\Yuzu"   安装到哪（默认有 D 盘就 D:\Yuzu，否则 C:\Yuzu）
#   -Qq 123456789     要登录的小号 QQ 号
#   -Owner 987654321  主人自己的 QQ 号（只有他说话才算主人）
#   -Key sk-xxxx      DeepSeek API Key
#   -QqDir "C:\Program Files\Tencent\QQNT"  已经装过 QQ 时指过去，跳过下载
#   -SkipDownload     跳过所有下载（文件已手动放好时用）
#   -NoStart          装完不启动服务
param(
    [string]$Root = "",
    [string]$Qq = "",
    [string]$Owner = "",
    [string]$Key = "",
    [string]$QqDir = "",
    [switch]$SkipDownload,
    [switch]$NoStart
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Say($s) { Write-Host $s }
function Die($s) { Write-Host ("✗ " + $s) -ForegroundColor Red; exit 1 }

Say "玉子控制台 · 一键部署"
Say ("包位置：" + $here)

# --- 0. 管理员 ---
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Say "需要管理员权限，正在请求提权…"
    $a = "-ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`""
    if ($Root) { $a += " -Root `"$Root`"" }
    if ($Qq) { $a += " -Qq $Qq" }
    if ($Owner) { $a += " -Owner $Owner" }
    if ($Key) { $a += " -Key `"$Key`"" }
    if ($QqDir) { $a += " -QqDir `"$QqDir`"" }
    if ($SkipDownload) { $a += " -SkipDownload" }
    if ($NoStart) { $a += " -NoStart" }
    Start-Process powershell -Verb RunAs -ArgumentList $a
    exit
}

# --- 1. 目录 ---
if (-not $Root) {
    if (Test-Path "D:\") { $Root = "D:\Yuzu" } else { $Root = "C:\Yuzu" }
}
New-Item -ItemType Directory -Force -Path $Root | Out-Null
Say ("安装到：" + $Root)

# --- 2. 交互补齐参数 ---
if (-not $Qq) { $Qq = Read-Host "要登录的小号 QQ 号（手机 QQ 扫码登录这个号）" }
if (-not $Owner) { $Owner = Read-Host "主人自己的 QQ 号（只有这个号发消息才会被回复）" }
if (-not $Key) { $Key = Read-Host "DeepSeek API Key（sk- 开头）" }
if (-not $Qq -or -not $Owner -or -not $Key) { Die "三个参数都必须有" }

$Need = 6GB
$free = (Get-PSDrive -Name $Root.Substring(0,1)).Free
if ($free -lt $Need) { Die ("磁盘空间不够，需要 6GB，可用 " + [math]::Round($free/1GB,1) + "GB") }

function Download($url, $dst, $minMB = 1) {
    if ($SkipDownload) { if (Test-Path $dst) { return } else { Die "SkipDownload 但缺文件：" + $dst } }
    if (Test-Path $dst) {
        $mb = (Get-Item $dst).Length / 1MB
        if ($mb -ge $minMB) { Say ("  已存在，跳过：" + (Split-Path $dst -Leaf) + "（" + [math]::Round($mb,1) + "MB）"); return }
        Remove-Item $dst -Force
    }
    Say ("  下载 " + (Split-Path $dst -Leaf) + " …")
    $old = $ProgressPreference
    $ProgressPreference = "SilentlyContinue"
    try {
        Invoke-WebRequest -Uri $url -OutFile $dst -UseBasicParsing -TimeoutSec 1800
    } catch {
        Die ("下载失败：" + $url + "`n" + $_.Exception.Message)
    } finally { $ProgressPreference = $old }
    $mb = (Get-Item $dst).Length / 1MB
    if ($mb -lt $minMB) { Die ("下载不完整：" + $dst + " 只有 " + [math]::Round($mb,1) + "MB") }
    Say ("  完成 " + [math]::Round($mb,1) + "MB")
}

$dl = Join-Path $Root "_download"
New-Item -ItemType Directory -Force -Path $dl | Out-Null

# --- 3. Node ---
Say "[1/6] Node.js"
$node = Join-Path $Root "node\node.exe"
if (Test-Path $node) {
    Say "  已存在：$node"
} else {
    $cmdNode = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmdNode) {
        $node = $cmdNode.Source
        Say ("  用系统已装的：" + $node)
    } else {
        $zip = Join-Path $dl "node-win-x64.zip"
        Download "https://registry.npmmirror.com/-/binary/node/v24.9.0/node-v24.9.0-win-x64.zip" $zip 20
        Expand-Archive -Path $zip -DestinationPath (Join-Path $Root "node-tmp") -Force
        $inner = Get-ChildItem (Join-Path $Root "node-tmp") -Directory | Select-Object -First 1
        Move-Item $inner.FullName (Join-Path $Root "node") -Force
        Remove-Item (Join-Path $Root "node-tmp") -Recurse -Force
        $node = Join-Path $Root "node\node.exe"
        if (-not (Test-Path $node)) { Die "Node 解压失败" }
        Say "  便携版就绪"
    }
}

# --- 4. ffmpeg（可选，失败不致命）---
Say "[2/6] ffmpeg（视频抽帧用，失败可跳过）"
$ffdir = Join-Path $Root "tools"
New-Item -ItemType Directory -Force -Path $ffdir | Out-Null
$ffexe = Join-Path $ffdir "ffmpeg.exe"
if (Test-Path $ffexe) {
    Say "  已存在"
} else {
    try {
        $gz = Join-Path $dl "ffmpeg.exe.gz"
        Download "https://cdn.npmmirror.com/binaries/ffmpeg-static/b6.0/ffmpeg-win32-x64.gz" $gz 10
        $in = [IO.File]::OpenRead($gz)
        $outS = [IO.File]::Create($ffexe)
        $gzS = New-Object IO.Compression.GzipStream($in, [IO.Compression.CompressionMode]::Decompress)
        $gzS.CopyTo($outS)
        $gzS.Dispose(); $outS.Dispose(); $in.Dispose()
        Say ("  完成 " + [math]::Round((Get-Item $ffexe).Length/1MB,1) + "MB")
    } catch {
        Say ("  ⚠ 跳过 ffmpeg：" + $_.Exception.Message + "（之后可在控制台一键安装）")
    }
}

# --- 5. QQ + NapCat ---
Say "[3/6] QQ 与 NapCat"
$napdir = Join-Path $Root "NapCat\NapCat.Shell"
if ($QqDir) {
    Say ("  用已有 QQ：" + $QqDir)
    if (-not (Test-Path (Join-Path $QqDir "QQ.exe"))) { Die "你这目录里没有 QQ.exe：" + $QqDir }
    New-Item -ItemType Directory -Force -Path $napdir | Out-Null
    Copy-Item (Join-Path $QqDir "*") $napdir -Recurse -Force
} else {
    $qqInstaller = Join-Path $dl "QQ_setup.exe"
    Download "https://github.com/Rodert/qq-versions/releases/download/qq-packages-20260813-1d08f1d4/QQ_9.9.33_260813_x64_01.exe" $qqInstaller 200
    Say "  静默安装 QQ（314MB，几分钟，别关窗口）…"
    $p = Start-Process $qqInstaller -ArgumentList "/S" -PassThru -Wait
    Say ("  安装器退出码：" + $p.ExitCode)
    $cands = @(
        "C:\Program Files\Tencent\QQNT",
        "C:\Program Files (x86)\Tencent\QQNT",
        (Join-Path $env:LOCALAPPDATA "Programs\Tencent\QQNT")
    )
    $qqFound = $null
    foreach ($c in $cands) { if (Test-Path (Join-Path $c "QQ.exe")) { $qqFound = $c; break } }
    if (-not $qqFound) { Die "QQ 装完没找到 QQ.exe，请手动装一次 QQ 再用 -QqDir 参数重跑" }
    Say ("  QQ 在：" + $qqFound)
    New-Item -ItemType Directory -Force -Path $napdir | Out-Null
    Copy-Item (Join-Path $qqFound "*") $napdir -Recurse -Force
}

$napzip = Join-Path $dl "NapCat.Shell.zip"
Download "https://github.com/NapNeko/NapCatQQ/releases/download/v4.18.38/NapCat.Shell.zip" $napzip 20
Expand-Archive -Path $napzip -DestinationPath $napdir -Force
if (-not (Test-Path (Join-Path $napdir "NapCatWinBootMain.exe"))) { Die "NapCat 解压后缺 NapCatWinBootMain.exe" }
Say "  NapCat 就绪"

# --- 6. 部署核心 ---
Say "[4/6] 复制程序 / 写配置"
$core = Join-Path $here "deploy-core.mjs"
if (-not (Test-Path $core)) { $core = Join-Path $here "deploy\deploy-core.mjs" }
$coreArgs = @($core, "--root", $Root, "--qq", $Qq, "--owner", $Owner, "--key", $Key, "--napcat", $napdir, "--node", $node)
if ($NoStart) { $coreArgs += "--skip-start" }
& $node @coreArgs
if ($LASTEXITCODE -ne 0) { Die "部署核心失败，看 $Root\deploy.log" }

# --- 7. 自启（注册表 + 计划任务 + 快捷方式）---
Say "[5/6] 开机自启"
$runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$trayExe = Join-Path $Root "玉子软件开发\玉子控制台.exe"
$runBat = Join-Path $Root "run-bridge.bat"
@"
@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "$Root\start-console.ps1"
call "$Root\qq-bridge\autostart.bat"
"@ | Set-Content -Path $runBat -Encoding ASCII
$runExe = Join-Path $Root "run-bridge.exe"
$csc = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (Test-Path $csc) {
    $cs = Join-Path $Root "RunHidden.cs"
    @"
using System;using System.Diagnostics;
static class L{static int Main(){
 try{var p=new ProcessStartInfo("cmd.exe","/c \`"$runBat\`"");
 p.UseShellExecute=false;p.CreateNoWindow=true;p.WorkingDirectory=@"$Root";p.WindowStyle=ProcessWindowStyle.Hidden;
 Process.Start(p);return 0;}catch{return 1;}}}
"@ | Set-Content -Path $cs -Encoding UTF8
    & $csc /nologo /codepage:65001 /target:winexe /out:$runExe $cs | Out-Null
}
Set-ItemProperty -Path $runKey -Name "QQBridge_AutoStart" -Value ('wscript.exe "' + (Join-Path $Root "qq-bridge\qq-bridge-startup.vbs") + '"')
$tr = if (Test-Path $runExe) { $runExe } else { "cmd.exe /c `"$runBat`"" }
& schtasks /create /tn "QQBridge-KeepAlive" /tr $tr /sc minute /mo 2 /f | Out-Null
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "玉子控制台.lnk"))
$lnk.TargetPath = $trayExe
$lnk.WorkingDirectory = (Split-Path $trayExe -Parent)
$lnk.IconLocation = (Join-Path $Root "玉子软件开发\assets\yuzu.ico") + ",0"
$lnk.Save()
Say "  自启 + 计划任务 + 桌面快捷方式 已建"

# --- 8. 验收 ---
Say "[6/6] 验收"
$check = Join-Path $Root "检查安装.ps1"
if (Test-Path $check) {
    powershell -NoProfile -ExecutionPolicy Bypass -File $check -NoPause
} else {
    Say "  （没找到 检查安装.ps1，跳过）"
}
Say ""
Say "部署完成。"
Say ("  控制台：" + $trayExe)
Say ("  日志：" + (Join-Path $Root "deploy.log"))
Say "  手机 QQ 扫码登录小号后，给玉子发一句话试试。"
if (-not $NoStart) { Start-Process $trayExe }
