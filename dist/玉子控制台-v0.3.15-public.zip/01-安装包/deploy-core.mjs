// 玉子控制台 · 部署核心（目标机运行，Node 20+，零第三方依赖）
// 用法：node deploy-core.mjs --root "D:\Yuzu" --qq 123456 --owner 987654 --key sk-xxx
// 可选：--napcat <NapCat 目录>  --node <node.exe>  --dry  --skip-start  --edge <msedge.exe>
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const opt = (name, def = '') => {
  const i = argv.indexOf('--' + name);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : def;
};
const flag = (name) => argv.includes('--' + name);

const ROOT = path.resolve(opt('root', 'D:\\Yuzu'));
const QQ = opt('qq');
const BOT = QQ;
const OWNER = opt('owner');
const KEY = opt('key');
const NAPCAT_DIR = path.resolve(opt('napcat', path.join(ROOT, 'NapCat', 'NapCat.Shell')));
const NODE_EXE = opt('node', process.execPath);
const DRY = flag('dry');
const SKIP_START = flag('skip-start');
const BRIDGE = path.join(ROOT, 'qq-bridge');
const APP = path.join(ROOT, '玉子软件开发');
const TOOLS = path.join(ROOT, 'tools');
const LOG = [];

function say(s) { console.log(s); LOG.push(s); }
function step(name, fn) {
  process.stdout.write('· ' + name + ' … ');
  try {
    const r = fn();
    console.log('OK' + (r ? '（' + r + '）' : ''));
    LOG.push('[OK] ' + name + (r ? ' ' + r : ''));
    return true;
  } catch (e) {
    console.log('FAIL: ' + e.message);
    LOG.push('[FAIL] ' + name + ' :: ' + e.message);
    return false;
  }
}
const mkdir = (p) => fs.mkdirSync(p, { recursive: true });

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}

function copyDir(src, dst) {
  mkdir(dst);
  let n = 0;
  for (const f of walk(src)) {
    const rel = path.relative(src, f);
    const target = path.join(dst, rel);
    mkdir(path.dirname(target));
    if (/(^|[\\/])(\.env|persona\.md)$/.test(rel) || /^(data|inbox)[\\/]/.test(rel)) {
      if (fs.existsSync(target)) continue;
    }
    fs.copyFileSync(f, target);
    n++;
  }
  return n;
}

// 找 payload：包根目录\payload 或 deploy\..\payload
function findPayload() {
  const cands = [
    path.join(HERE, 'payload'),
    path.join(HERE, '..', 'payload'),
    path.join(HERE, '..', '..', 'payload'),
    path.join(HERE, '..', 'dist', '玉子控制台-安装包', 'payload'),
  ];
  for (const c of cands) {
    if (fs.existsSync(path.join(c, 'bridge', 'bot.mjs'))) return path.resolve(c);
  }
  throw new Error('找不到 payload（应有 payload\\bridge\\bot.mjs）');
}

const SUBS = [
  [/D:\\DeepSeek test\\qq-bridge/gi, BRIDGE],
  [/D:\\DeepSeek test\\玉子软件开发/gi, APP],
  [/D:\\DeepSeek test\\tools/gi, TOOLS],
  [/D:\\DeepSeek test/gi, ROOT],
  [/D:\\NapCat\\NapCat\.52230\.Shell/gi, NAPCAT_DIR],
  [/D:\\NapCat\\(?=[^\\])/gi, path.join(ROOT, 'NapCat') + '\\'],
  [/C:\\Program Files\\nodejs\\node\.exe/gi, NODE_EXE],
];

function patchTree(dir) {
  const exts = new Set(['.mjs', '.js', '.bat', '.vbs', '.html', '.md', '.txt', '.ps1', '.json', '.cs']);
  let files = 0, hits = 0;
  for (const f of walk(dir)) {
    if (!exts.has(path.extname(f).toLowerCase())) continue;
    const raw = fs.readFileSync(f, 'utf8');
    let t = raw, h = 0;
    for (const [re, to] of SUBS) t = t.replace(re, () => { h++; return to; });
    if (h > 0) {
      if (!DRY) fs.writeFileSync(f, t, 'utf8');
      files++; hits += h;
    }
  }
  return files + ' 个文件 / ' + hits + ' 处';
}

function findVersionDir() {
  const vs = path.join(NAPCAT_DIR, 'versions');
  if (!fs.existsSync(vs)) return null;
  const list = fs.readdirSync(vs).filter((d) => fs.existsSync(path.join(vs, d, 'resources')));
  list.sort();
  return list.length ? path.join(vs, list[list.length - 1]) : null;
}

function writeNapCatConfig() {
  if (!QQ) throw new Error('缺少 --qq');
  const vdir = findVersionDir();
  if (!vdir) throw new Error('找不到 NapCat 的 versions\\<版本>（NapCat 还没解压到 ' + NAPCAT_DIR + '？）');
  const cfgDir = path.join(vdir, 'resources', 'app', 'napcat', 'config');
  mkdir(cfgDir);
  const file = path.join(cfgDir, 'onebot11_' + QQ + '.json');
  const cfg = {
    network: {
      httpServers: [], httpSseServers: [], httpClients: [], websocketClients: [], plugins: [],
      websocketServers: [{
        name: 'yuzu-bridge', enable: true, host: '127.0.0.1', port: 3001,
        messagePostFormat: 'array', token: '', enableForcePushEvent: true,
        reportSelfMessage: false, debug: false, heartInterval: 30000,
      }],
    },
    musicSignUrl: '', enableLocalFile2Url: false, parseMultMsg: false,
    packetBackend: 'auto', packetServer: '', o3HookMode: 1,
  };
  if (!DRY) fs.writeFileSync(file, JSON.stringify(cfg, null, 2), 'utf8');
  return path.basename(file);
}

function writeEnv() {
  if (!OWNER || !KEY) throw new Error('缺少 --owner 或 --key');
  const p = path.join(BRIDGE, '.env');
  const lines = [
    '# 玉子 bot 配置（部署器 ' + new Date().toISOString() + '）',
    'OWNER_QQ=' + OWNER,
    'BOT_QQ=' + (BOT || OWNER),
    'DEEPSEEK_API_KEY=' + KEY,
    'DEEPSEEK_BASE=https://api.deepseek.com',
    'MODEL=deepseek-flash',
    'NAPCAT_WS=ws://127.0.0.1:3001',
    'NAPCAT_TOKEN=',
    'MAX_MSG_PER_MIN=6',
    'FFMPEG_PATH=' + path.join(TOOLS, 'ffmpeg.exe'),
    'WATCH_GROUPS=',
    'SUMMARY_AT=21:30',
    'EXTRA_WHITELIST=',
    'GROUP_REPLY=mention',
    'GROUP_COOLDOWN=20',
    'FRIEND_REPLY=1',
    'FRIEND_COOLDOWN=60',
    'WEATHER_ON=1',
    'WEATHER_AT=07:30',
    'WEATHER_CITY=wuhan',
    '',
  ];
  if (!DRY) fs.writeFileSync(p, lines.join('\r\n'), 'utf8');
  return 'OWNER_QQ=' + OWNER;
}

function writeBotQq() {
  const d = path.join(BRIDGE, 'data');
  fs.mkdirSync(d, { recursive: true });
  fs.writeFileSync(path.join(d, 'bot-qq.txt'), String(BOT || OWNER), 'ascii');
  return 'bot-qq.txt = ' + (BOT || OWNER);
}

function compileTray() {
  const csc = 'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe';
  if (!fs.existsSync(csc)) throw new Error('找不到 csc.exe（需 .NET Framework 4.x，Win10/11 自带）');
  const src = path.join(APP, 'src', 'YuzuTray.cs');
  if (!fs.existsSync(src)) throw new Error('缺 src\\YuzuTray.cs');
  const out = path.join(APP, '玉子控制台.exe');
  const ico = path.join(APP, 'assets', 'yuzu.ico');
  const a = ['/nologo', '/codepage:65001', '/target:winexe'];
  if (fs.existsSync(ico)) a.push('/win32icon:' + ico);
  a.push('/out:' + out, src);
  const r = spawnSync(csc, a, { encoding: 'utf8' });
  if (r.status !== 0) throw new Error((r.stdout || '') + (r.stderr || ''));
  return Math.round(fs.statSync(out).size / 1024) + 'KB';
}

function startServices() {
  const nap = path.join(NAPCAT_DIR, 'NapCatWinBootMain.exe');
  if (!fs.existsSync(nap)) throw new Error('找不到 ' + nap);
  spawn('cmd.exe', ['/c', 'start', '', '/b', nap, QQ], { cwd: NAPCAT_DIR, detached: true, stdio: 'ignore', windowsHide: true }).unref();
  mkdir(path.join(BRIDGE, 'data'));
  for (const [script, log] of [['bot.mjs', 'bot.log'], ['console.mjs', 'console.out.log']]) {
    const fd = fs.openSync(path.join(BRIDGE, 'data', log), 'a');
    spawn(NODE_EXE, [script], { cwd: BRIDGE, detached: true, windowsHide: true, stdio: ['ignore', fd, fd] }).unref();
  }
  return 'NapCat + bot + console';
}

// ---- 主流程 ----
say('玉子控制台 · 部署核心');
say('目标目录：' + ROOT + (DRY ? '  [演练模式：不写盘]' : ''));
const payload = findPayload();
say('安装包来源：' + payload);
const ok = [];

ok.push(step('目标目录可写', () => {
  if (DRY) return 'dry';
  mkdir(ROOT);
  const p = path.join(ROOT, '.wt');
  fs.writeFileSync(p, 'ok');
  fs.unlinkSync(p);
  return ROOT;
}));
ok.push(step('复制程序到 qq-bridge', () => (DRY ? 'dry' : copyDir(path.join(payload, 'bridge'), BRIDGE) + ' 个文件')));
ok.push(step('复制托盘资源到 玉子软件开发', () => (DRY ? 'dry' : copyDir(path.join(payload, 'app'), APP) + ' 个文件')));
ok.push(step('改写写死路径', () => (DRY ? 'dry' : patchTree(BRIDGE) + ' | ' + patchTree(APP))));
ok.push(step('写 .env', () => (DRY ? 'dry' : writeEnv())));
ok.push(step('写 data\\bot-qq.txt', () => (DRY ? 'dry' : writeBotQq())));
ok.push(step('写 NapCat 网络配置（WS 3001）', () => (DRY ? 'dry' : writeNapCatConfig())));
ok.push(step('编译托盘 exe', () => (DRY ? 'dry' : compileTray())));
ok.push(step('启动服务', () => (DRY || SKIP_START ? 'skip' : startServices())));
ok.push(step('写部署日志', () => {
  if (DRY) return 'dry';
  fs.writeFileSync(path.join(ROOT, 'deploy.log'), LOG.join('\r\n') + '\r\n', 'utf8');
  return path.join(ROOT, 'deploy.log');
}));

const pass = ok.filter(Boolean).length;
say('');
say('完成：' + pass + ' / ' + ok.length + ' 步');
if (pass < ok.length) {
  say('有失败步骤，看 deploy.log；常见原因：没管理员权限 / 网络下载失败 / NapCat 没解压好。');
  process.exitCode = 1;
} else {
  say('');
  say('接下来：');
  say('  1) 手机 QQ 扫码登录小号（二维码：控制台首页「登录二维码」，或 NapCat 窗口）');
  say('  2) 打开 ' + path.join(APP, '玉子控制台.exe'));
  say('  3) 验收：' + path.join(ROOT, '检查安装.bat'));
}
