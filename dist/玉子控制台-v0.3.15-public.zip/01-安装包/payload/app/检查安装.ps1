# 玉子控制台 · 安装验收（只读检查，不改任何东西）
$ErrorActionPreference = 'SilentlyContinue'
$ok = 0; $bad = 0

function Check($name, $script, $detail) {
    $r = $null
    try { $r = & $script } catch { $r = $null }
    if ($r) {
        Write-Host ("  [OK]   " + $name) -ForegroundColor Green
        if ($detail) { Write-Host ("         " + $detail) -ForegroundColor DarkGray }
        $script:ok++
    } else {
        Write-Host ("  [缺失] " + $name) -ForegroundColor Red
        if ($detail) { Write-Host ("         " + $detail) -ForegroundColor DarkGray }
        $script:bad++
    }
}

Write-Host ""
Write-Host "玉子控制台 · 安装验收" -ForegroundColor Cyan
Write-Host ("时间 " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) -ForegroundColor DarkGray
Write-Host ""

Check "程序目录 D:\DeepSeek test\qq-bridge" { Test-Path 'D:\DeepSeek test\qq-bridge\bot.mjs' } 'bot.mjs / console.mjs / web'
Check "托盘程序 玉子控制台.exe" { Test-Path 'D:\DeepSeek test\玉子软件开发\玉子控制台.exe' } '右下角绿色小图标就是这个'
Check "启动脚本 C:\DSH\run-bridge.bat" { Test-Path 'C:\DSH\run-bridge.bat' } '计划任务每 2 分钟调它'
Check "静默启动器 C:\DSH\run-bridge.exe" { Test-Path 'C:\DSH\run-bridge.exe' } '无窗口版，防闪黑框'
Check "桌面快捷方式" { Test-Path (Join-Path ([Environment]::GetFolderPath('Desktop')) '玉子控制台.lnk') } '桌面「玉子控制台」'
Check "开机自启（注册表）" { (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'QQBridge_AutoStart').QQBridge_AutoStart } 'HKCU Run 里的 QQBridge_AutoStart'
Check "计划任务 QQBridge-KeepAlive" { Get-ScheduledTask -TaskName 'QQBridge-KeepAlive' } '每 2 分钟自检一次'
Check "控制台后端 3210" { Test-NetConnection 127.0.0.1 -Port 3210 -InformationLevel Quiet } '网页后台'
Check "NapCat 3001（QQ 协议端）" { Test-NetConnection 127.0.0.1 -Port 3001 -InformationLevel Quiet } '不通 = QQ 没登录/没启动'
Check "玉子 bot 3008" { Test-NetConnection 127.0.0.1 -Port 3008 -InformationLevel Quiet } '聊天主进程'
Check "无头 Edge 9333（空间点赞用）" { Test-NetConnection 127.0.0.1 -Port 9333 -InformationLevel Quiet } 'CDP 调试口'
Check "配置 .env（含 API key）" { (Select-String -Path 'D:\DeepSeek test\qq-bridge\.env' -Pattern '^DEEPSEEK_API_KEY=sk-').Count -gt 0 } '没有它就没法聊天'
Check "聊天记忆 data\brain" { Test-Path 'D:\DeepSeek test\qq-bridge\data\brain\messages.jsonl' } '聊天记录存这里'

Write-Host ""
if ($bad -eq 0) {
    Write-Host ("全部通过：" + $ok + " 项") -ForegroundColor Green
} else {
    Write-Host ("通过 " + $ok + " 项，缺失 " + $bad + " 项") -ForegroundColor Yellow
    Write-Host "缺的项可以在控制台「插件·升级 → 安装与修复」里点一键补，或把 install.log 发给主人的人工智能女仆。" -ForegroundColor DarkGray
}
Write-Host ""
Write-Host "按任意键关闭…" -ForegroundColor DarkGray
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
