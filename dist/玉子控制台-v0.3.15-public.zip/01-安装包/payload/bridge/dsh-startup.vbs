' 开机自启 DeepSeek Harness（延迟 15 秒，等桌面/网络就绪）
Option Explicit
Dim sh, fso, exe, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

exe = "D:\DeepSeek harness\DeepSeek Harness.exe"
WScript.Sleep 15000

If fso.FileExists(exe) Then
  cmd = Chr(34) & exe & Chr(34)
  On Error Resume Next
  sh.Run cmd, 1, False
  If Err.Number <> 0 Then
    Dim f
    Set f = fso.OpenTextFile("D:\DeepSeek test\qq-bridge\data\vbs-error.log", 8, True)
    f.WriteLine Now & " DSH 启动失败: " & Err.Number & " " & Err.Description
    f.Close
  End If
  On Error Goto 0
End If
