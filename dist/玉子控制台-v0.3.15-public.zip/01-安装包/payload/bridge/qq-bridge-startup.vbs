Option Explicit
Dim sh, fso, base, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

base = "D:\DeepSeek test\qq-bridge"
WScript.Sleep 20000

sh.CurrentDirectory = base
cmd = Chr(34) & base & "\autostart.bat" & Chr(34)

On Error Resume Next
sh.Run cmd, 0, False
If Err.Number <> 0 Then
  Dim f
  Set f = fso.OpenTextFile(base & "\data\vbs-error.log", 8, True)
  f.WriteLine Now & " Run 失败: " & Err.Number & " " & Err.Description
  f.Close
End If
On Error Goto 0
